# postgresdave
My database wrapper on psycopg2

# Build steps
py -m build
py -m twine upload --repository pypi dist/*
