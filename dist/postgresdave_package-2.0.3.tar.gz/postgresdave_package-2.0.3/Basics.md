# postgres-basics
Basic things everyone using Postgres should know
