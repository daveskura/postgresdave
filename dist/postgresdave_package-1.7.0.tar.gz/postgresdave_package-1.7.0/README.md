# postgresdave
A simple wrapper on psycopg2 to access Postgres

### install with pip
pip install postgresdave_package

### command line test
py -m postgresdave_package.postgresdave

### Quick Start Guide
https://github.com/daveskura/postgresdave/blob/main/QuickStart.md

### Methods
https://github.com/daveskura/postgresdave/blob/main/methods.md
